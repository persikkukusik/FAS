from __future__ import annotations

from .model import Scene, SceneObject, Transform


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def _cubic_bezier_value(
    a_y: float, out_y: float, in_y: float, b_y: float, t: float
) -> float:
    u = 1.0 - t
    return (
        u * u * u * a_y
        + 3.0 * u * u * t * out_y
        + 3.0 * u * t * t * in_y
        + t * t * t * b_y
    )


def _handle_y(kf, prev, next_) -> None:
    """Compute the auto-clamped Bézier handle Y-offsets for a keyframe.

    Faithful port of Blender's `calchandleNurb_intern` for F-Curves using
    "Auto Clamped" handles wrapped in the default "Continuous Acceleration"
    smoothing. Handles are forced to sit at 1/3 of the neighbouring keyframe
    time intervals (so X is a linear function of the curve parameter, i.e.
    `t` == normalized time), their height follows the tangent formed by the
    two adjacent keys, and they are clamped so the curve never overshoots
    beyond the Y values of the neighbouring keys.

    Returns (left_handle_y, right_handle_y).
    """
    if prev is None:
        prev = kf
    if next_ is None:
        next_ = kf

    # Deltas (X and Y) between neighbouring keys and this key.
    dvec_a_y = kf.value - prev.value
    dvec_b_y = next_.value - kf.value
    len_a = kf.frame - prev.frame
    len_b = next_.frame - kf.frame

    if len_a == 0.0:
        len_a = 1.0
    if len_b == 0.0:
        len_b = 1.0

    # Tangent direction (sum of normalized neighbour deltas).
    # tvec[0] == 1 + 1 == 2, since X deltas are normalised to both neighbours.
    tvec_y = dvec_b_y / len_b + dvec_a_y / len_a

    # With smoothing active (default) the handle X-spacing is forced to 1/3 of
    # the interval; the magic constant collapses to len == 6.0.
    len_handle = 6.0 / 2.5614
    len_handle *= 2.5614

    left_y = kf.value - (len_a / len_handle) * tvec_y
    right_y = kf.value + (len_b / len_handle) * tvec_y

    left_x = kf.frame - len_a / 3.0
    right_x = kf.frame + len_b / 3.0
    h1_x = left_x - kf.frame
    h2_x = kf.frame - right_x

    if prev is not kf and next_ is not kf:
        ydiff1 = prev.value - kf.value
        ydiff2 = next_.value - kf.value

        leftviolate = False
        rightviolate = False

        if (ydiff1 <= 0.0 and ydiff2 <= 0.0) or (ydiff1 >= 0.0 and ydiff2 >= 0.0):
            # Vertices/extrema -> keep handle horizontal (no overshoot).
            left_y = kf.value
            right_y = kf.value
        else:
            # Handles must not go beyond the Y coords of the two neighbours.
            if ydiff1 <= 0.0:
                if prev.value > left_y:
                    left_y = prev.value
                    leftviolate = True
            else:
                if prev.value < left_y:
                    left_y = prev.value
                    leftviolate = True

            if ydiff1 <= 0.0:
                if next_.value < right_y:
                    right_y = next_.value
                    rightviolate = True
            else:
                if next_.value > right_y:
                    right_y = next_.value
                    rightviolate = True

        if leftviolate or rightviolate:
            # Keep the two handles aligned about the key.
            if leftviolate:
                if h1_x != 0.0:
                    right_y = kf.value + ((kf.value - left_y) / h1_x) * h2_x
            else:
                if h2_x != 0.0:
                    left_y = kf.value + ((kf.value - right_y) / h2_x) * h1_x

    return left_y, right_y


def _segment_handles(keyframes: list, i: int):
    """Return the cubic Bézier control-point Y values for segment [i, i+1].

    Control points are: (a.value, a_out_y, b_in_y, b.value), where
    `a_out_y` is the right handle of key i and `b_in_y` is the left handle of
    key i+1 -- exactly the two handles Blender uses to evaluate an F-Curve.
    """
    a = keyframes[i]
    b = keyframes[i + 1]

    prev_a = keyframes[i - 1] if i - 1 >= 0 else a
    next_a = keyframes[i + 1] if i + 1 < len(keyframes) else a
    _, a_out_y = _handle_y(a, prev_a, next_a)

    prev_b = keyframes[i] if i >= 0 else b
    next_b = keyframes[i + 2] if i + 2 < len(keyframes) else b
    b_in_y, _ = _handle_y(b, prev_b, next_b)

    return a_out_y, b_in_y


def _interpolate_segment(keyframes: list, i: int, t: float) -> float:
    a = keyframes[i]
    b = keyframes[i + 1]
    if a.frame == b.frame:
        return a.value
    mode = getattr(a, "interpolation", "cubic")
    if mode == "constant":
        return a.value
    if mode == "linear":
        return a.value + (b.value - a.value) * t
    if len(keyframes) == 2:
        return a.value + (b.value - a.value) * t
    a_out_y, b_in_y = _segment_handles(keyframes, i)
    return _cubic_bezier_value(a.value, a_out_y, b_in_y, b.value, t)


def interpolate_channel(keyframes: list, frame: int) -> float | None:
    if not keyframes:
        return None
    if len(keyframes) == 1:
        return keyframes[0].value
    if frame <= keyframes[0].frame:
        return keyframes[0].value
    if frame >= keyframes[-1].frame:
        return keyframes[-1].value
    for i in range(len(keyframes) - 1):
        kf_a = keyframes[i]
        kf_b = keyframes[i + 1]
        if kf_a.frame <= frame <= kf_b.frame:
            if kf_a.frame == kf_b.frame:
                return kf_a.value
            t = (frame - kf_a.frame) / (kf_b.frame - kf_a.frame)
            return _interpolate_segment(keyframes, i, t)
    return keyframes[-1].value


def apply_interpolation(scene: Scene, frame: int) -> None:
    channels = {
        "position_x": "x",
        "position_y": "y",
        "rotation": "rotation",
        "scale_x": "scale_x",
        "scale_y": "scale_y",
    }
    for obj in scene.iter_objects():
        for ch_key, attr in channels.items():
            kfs = obj.get_keyframes(ch_key)
            if kfs:
                val = interpolate_channel(kfs, frame)
                if val is not None:
                    setattr(obj.transform, attr, val)


def set_keyframe_at_current_frame(obj: SceneObject, frame: int) -> None:
    t = obj.transform
    obj.set_keyframe(frame, "position_x", t.x)
    obj.set_keyframe(frame, "position_y", t.y)
    obj.set_keyframe(frame, "rotation", t.rotation)
    obj.set_keyframe(frame, "scale_x", t.scale_x)
    obj.set_keyframe(frame, "scale_y", t.scale_y)
