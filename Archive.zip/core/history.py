from __future__ import annotations

import copy
from typing import TYPE_CHECKING

from core.selection import (
    KeyframeSelectionState,
    deserialize_keyframe_selection,
    serialize_keyframe_selection,
)

if TYPE_CHECKING:
    from core.model import Scene


MAX_HISTORY = 100


class History:
    def __init__(self, scene: Scene):
        self.scene = scene
        self.selected_id: str | None = None
        self.keyframe_selection: list[tuple[str, int]] = serialize_keyframe_selection(
            KeyframeSelectionState.selected()
        )
        self._undo_stack: list[tuple[Scene, str | None, list]] = []
        self._redo_stack: list[tuple[Scene, str | None, list]] = []

    def save_scene(self) -> None:
        self._push(copy.deepcopy(self.scene), self.selected_id, list(self.keyframe_selection))

    def discard_last_save(self) -> None:
        """Pop the most recently saved state from the undo stack. Used when an
        operation that snapshotted the scene turns out to be a no-op (e.g. a
        cancelled reorder-drop), so it doesn't leave a phantom undo step."""
        if self._undo_stack:
            self._undo_stack.pop()

    def save_selection(self, selected_id: str | None) -> None:
        if selected_id == self.selected_id:
            return
        previous = self.selected_id
        self.selected_id = selected_id
        self._push(copy.deepcopy(self.scene), previous, list(self.keyframe_selection))

    def save_keyframe_selection(self, selection: list[tuple[str, int]]) -> None:
        """Record a user-initiated keyframe selection change as an undoable step."""
        if selection == self.keyframe_selection:
            return
        previous = self.keyframe_selection
        self.keyframe_selection = list(selection)
        self._push(copy.deepcopy(self.scene), self.selected_id, previous)

    def sync_keyframe_selection(self) -> None:
        """Update the recorded keyframe selection *in place* (no history push).

        Used when a keyframe operation (move/scale/duplicate/delete) implicitly
        changes the selection (e.g. a moved keyframe lands on a new frame), so
        the next undo/redo reflects the new selection without creating a
        separate undo step.
        """
        self.keyframe_selection = serialize_keyframe_selection(
            KeyframeSelectionState.selected()
        )

    def sync_selection(self, selected_id: str | None) -> None:
        """Update the recorded selected object *in place* (no history push).

        Used when an object operation implicitly changes the selection (e.g.
        deleting the selected object deselects it), so that operation stays a
        single undo step and, on undo, the previously selected object is
        restored and re-selected.
        """
        self.selected_id = selected_id

    def _push(
        self,
        snapshot: Scene,
        selected_id: str | None,
        keyframe_selection: list[tuple[str, int]],
    ) -> None:
        self._undo_stack.append((snapshot, selected_id, keyframe_selection))
        if len(self._undo_stack) > MAX_HISTORY:
            self._undo_stack.pop(0)
        self._redo_stack.clear()

    def undo(self) -> bool:
        if not self._undo_stack:
            return False
        current = copy.deepcopy(self.scene)
        self._redo_stack.append(
            (current, self.selected_id, list(self.keyframe_selection))
        )
        snapshot, selected_id, kf_selection = self._undo_stack.pop()
        self._restore(snapshot)
        self.selected_id = selected_id
        self._restore_keyframe_selection(kf_selection)
        return True

    def redo(self) -> bool:
        if not self._redo_stack:
            return False
        current = copy.deepcopy(self.scene)
        self._undo_stack.append(
            (current, self.selected_id, list(self.keyframe_selection))
        )
        snapshot, selected_id, kf_selection = self._redo_stack.pop()
        self._restore(snapshot)
        self.selected_id = selected_id
        self._restore_keyframe_selection(kf_selection)
        return True

    def _restore_keyframe_selection(self, selection: list[tuple[str, int]]) -> None:
        self.keyframe_selection = list(selection)
        KeyframeSelectionState.set_selected(
            deserialize_keyframe_selection(self.scene, selection)
        )

    def _restore(self, snapshot: Scene) -> None:
        self.scene.objects[:] = snapshot.objects
        self.scene.start_frame = snapshot.start_frame
        self.scene.end_frame = snapshot.end_frame
        self.scene.fps = snapshot.fps
        self.scene.current_frame = snapshot.current_frame

    def can_undo(self) -> bool:
        return len(self._undo_stack) > 0

    def can_redo(self) -> bool:
        return len(self._redo_stack) > 0