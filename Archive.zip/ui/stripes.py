from __future__ import annotations

import time

from PySide6.QtGui import QColor, QImage, QTransform, QBrush, QPainter
from PySide6.QtCore import Qt


def _shared_clock() -> float:
    """A single monotonic clock (seconds) shared by every stripe shader.

    All shaders read this same value (multiplied by their own ``speed``) as
    their scroll phase, so any stripe pattern that appears - a new selection,
    a hover, a mask highlight, a drag preview - is always phase-aligned with
    every other one instead of each widget keeping its own counter and
    drifting out of sync.
    """
    return time.monotonic()



class StripeShader:
    """A reusable, seamless 45-degree scrolling stripe pattern.

    The pattern lives in a small seamless tile whose size equals the stripe
    period. Because it is filled as a repeated texture (rather than drawn as
    individual lines), it never pops regardless of how small or oddly shaped
    the clipped region is.

    The tile is cached by (color, thickness, gap), so it is built exactly
    once and reused everywhere.

    Class-level defaults: change them once and every instance (every dock,
    every script) is affected.
    """

    THICKNESS = 12
    GAP = 12
    PAD = 12.0
    SPEED = 30.0

    _TILE_CACHE: dict[tuple[int, int, int, int, int, int], QBrush] = {}

    def __init__(self, color: QColor | str = QColor(190, 190, 190),
                 thickness: int | None = None,
                 gap: int | None = None,
                 pad: float | None = None,
                 speed: float | None = None):
        """Create a stripe shader. All args default to the class-level values
        (``THICKNESS``, ``GAP``, ``PAD``, ``SPEED``). Override once on the
        class to change every instance at once, or pass per-instance here.
        """
        self.thickness = max(1, int(thickness)) if thickness is not None else self.THICKNESS
        self.gap = max(1, int(gap)) if gap is not None else self.GAP
        self.color = QColor(color)
        self.pad = float(pad) if pad is not None else self.PAD
        self.speed = float(speed) if speed is not None else self.SPEED

    def _get_tile(self) -> QBrush:
        period = int(self.thickness + self.gap)
        r, g, b = self.color.red(), self.color.green(), self.color.blue()
        key = (period, self.thickness, r, g, b, int(self.color.alpha()))
        brush = self._TILE_CACHE.get(key)
        if brush is not None:
            return brush

        thickness = self.thickness
        img = QImage(period, period, QImage.Format_ARGB32_Premultiplied)
        img.fill(QColor(0, 0, 0, 0))
        for y in range(period):
            for x in range(period):
                if (x + y) % period < thickness:
                    img.setPixelColor(x, y, self.color)
        brush = QBrush(img)
        self._TILE_CACHE[key] = brush
        return brush

    def brush(self, phase: float, zoom: float = 1.0) -> QBrush:
        """Return a stripe brush for the given scroll phase and zoom.

        ``phase`` is in device pixels (already scaled by ``speed``). The
        brush transform cancels the painter's ``zoom`` so the stripe pattern
        keeps a fixed on-screen size while scrolling.
        """
        inv_zoom = 1.0 / zoom if zoom > 0 else 1.0
        brush = QBrush(self._get_tile())
        phase_eff = int(phase)
        bt = QTransform(
            inv_zoom, 0, 0, inv_zoom,
            -phase_eff * inv_zoom,
            -phase_eff * inv_zoom,
        )
        brush.setTransform(bt)
        return brush

    def paint(self, painter: QPainter, clip_path, phase: float | None = None, zoom: float = 1.0) -> None:
        """Fill ``clip_path`` (painter's current coordinate space) with the
        animated stripes, keeping a fixed on-screen pattern size.

        ``phase`` is optional: when omitted it defaults to the app-wide shared
        clock, so every shader stays synchronized with the rest on screen.
        ``speed`` (in units per second) governs how fast the pattern scrolls.
        """
        if phase is None:
            phase = _shared_clock() * self.speed
        inv_zoom = 1.0 / zoom if zoom > 0 else 1.0
        brush = self.brush(phase, zoom)

        painter.save()
        painter.setClipPath(clip_path)
        pad = self.pad * inv_zoom
        rect = clip_path.boundingRect().adjusted(-pad, -pad, pad, pad)
        painter.setPen(Qt.NoPen)
        painter.setBrush(brush)
        painter.drawRect(rect)
        painter.restore()
